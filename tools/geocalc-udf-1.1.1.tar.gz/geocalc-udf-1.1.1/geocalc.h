//	geocalc.h
//

#ifndef GEO_CALCULATIONS_H_
#define GEO_CALCULATIONS_H_

  //
  // some geo constants
  //
namespace GEO {
	const double PI = 3.14159265359;
	const double PIOVER2 = PI/2.0;
	const double TWOPI = 6.28318530718;
	const double DE2RA = 0.01745329252;
	const double RA2DE = 57.2957795129;
	const double ERAD = 6378.137;
	const double ERADM = 6378137.0;
	const double AVG_ERAD = 6371.0;
	const double FLATTENING = 1.000000/298.257223563;// Earth flattening (WGS84)
	const double EPS = 0.000000000005;
	const double KM2MI = 0.621371;
	const double GEOSTATIONARY_ALT = 35786.0; // km - approximate value
}

  //
  // geographic calculations class - everything is static so there is no
  // need to create an object of type GeoCalc. if you want to use this class
  // just call the methods with a "GeoCalc::" prepended as in the sample code.
  //
class GeoCalc {
public:
	  // great circle methods
	static double GCDistance(double lat1, double lon1, double lat2, double lon2);
	static double GCAzimuth(double lat1, double lon1, double lat2, double lon2);
	static void GCDistanceAzimuth(double lat1, double lon1, double dist, double az,
		double& lat2, double& lon2);
	static void GCSatellite(double lat1, double lon1, double sat_lon,
		double& az, double& elev);
	static bool GCIntersectSegment(double lat1A, double lon1A, double lat1B, double lon1B,
		double lat2A, double lon2A, double lat2B, double lon2B,
		double& lat3A, double& lon3A, double& lat3B, double& lon3B);

	  // ellipsoid methods
	static double ApproxDistance(double lat1, double lon1, double lat2, double lon2);
	static double EllipsoidDistance(double lat1, double lon1, double lat2, double lon2);
	static double EllipsoidAzimuth(double lat1, double lon1, double lat2, double lon2);
	static double EllipseArcLength(double lat1, double lat2, double a = GEO::ERAD,
		double f = GEO::FLATTENING);

	  // utility methods
    static double GeoCalc::ConvertMilesToKilometers(double miles);
    static double GeoCalc::ConvertKilometersToMiles(double km);

};

#endif
