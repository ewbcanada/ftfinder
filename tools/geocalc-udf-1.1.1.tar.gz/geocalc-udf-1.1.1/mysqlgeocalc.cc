/*
 *   mysqlgeocalc.cc
 *
 *   UDF (User Defined Function) for MySQL
 *   Allows geographical calculations to be done inside of queries.
 *
 *   Example usage:
 *
 *   PostalCodes Table:
 *   	PostalCode	INT
 *   	Longitude	REAL
 *   	Latitude	REAL
 *
 *   SELECT Longitude AS RefLon, Latitude as RefLat FROM PostalCodes WHERE PostalCode = 12345;
 *
 *   Use RefLon and RefLat in the next query.  Radius will be the max distance in miles from
 *   the reference postal code.  It will return a list of all postal codes in the area:
 *
 *   SELECT PostalCode FROM PostalCodes WHERE KM_TO_MI(DISTANCE(RefLon,RefLat,Lonitude,Latitude)) <= Radius;
 *
 *   2006-05-24 Patch from Jerome Despatis <jerome@despatis.com>
 *              fix geocalc crashs when query on table that contains NULL field
 *              fix compile warnings (misc) and arguments check
 *              add Makefile
 */


#ifdef STANDARD
#include <string.h>
#ifdef __WIN__
typedef unsigned __int64 ulonglong;
typedef __int64 longlong;
#else
typedef unsigned long long ulonglong;
typedef long long longlong;
#endif /*__WIN__*/
#else
#include <my_global.h>
#include <my_sys.h>
#endif
#include <mysql.h>
#include <m_ctype.h>
#include <m_string.h>

#include "geocalc.h"

/******************************************************************************
** function declarations
******************************************************************************/
bool string2double(char* digit, double& result);

extern "C" {
	my_bool		ellipsoid_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message);
	void		ellipsoid_distance_deinit(UDF_INIT *initid);
	double		ellipsoid_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error);

	my_bool		gc_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message);
	void		gc_distance_deinit(UDF_INIT *initid);
	double		gc_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error);

	my_bool		approx_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message);
	void		approx_distance_deinit(UDF_INIT *initid);
	double		approx_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error);

	my_bool		km_to_miles_init(UDF_INIT *initid, UDF_ARGS *args, char *message);
	void		km_to_miles_deinit(UDF_INIT *initid);
	double		km_to_miles(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error);

	my_bool		miles_to_km_init(UDF_INIT *initid, UDF_ARGS *args, char *message);
	void		miles_to_km_deinit(UDF_INIT *initid);
	double		miles_to_km(UDF_INIT *initid, UDF_ARGS *args, char *is_null, char *error);

}

/******************************************************************************
** FUNCTION DEFINITIONS
******************************************************************************/


/*****************************
** ellipsoid_distance
******************************/

my_bool ellipsoid_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 4)
	{
		strcpy(message, "ELLIPSOID_DISTANCE() requires four arguments");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
  else if ((args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT) ||
           (args->arg_type[1] != REAL_RESULT && args->arg_type[1] != DECIMAL_RESULT) ||
           (args->arg_type[2] != REAL_RESULT && args->arg_type[2] != DECIMAL_RESULT) ||
           (args->arg_type[3] != REAL_RESULT && args->arg_type[3] != DECIMAL_RESULT) )
	{
		strcpy(message, "ELLIPSOID_DISTANCE() requires four decimal arguments");
		return 1;
	}

  /* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void ellipsoid_distance_deinit(UDF_INIT *initid)
{
}

double ellipsoid_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{
        double lat1;
        double lon1;
        double lat2;
        double lon2;

        // if one arg or more is null, then sends null
        *is_null = 0;
        if (!args->args[0] || !args->args[1] || !args->args[2] || !args->args[3]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],lat1);
        }
        else {
	    lat1 = *((double*) args->args[0]);
        }
	if (args->arg_type[1] == DECIMAL_RESULT) {
            string2double(args->args[1],lon1);
        }
        else {
	    lon1 = *((double*) args->args[1]);
        }
	if (args->arg_type[2] == DECIMAL_RESULT) {
            string2double(args->args[2],lat2);
        }
        else {
	    lat2 = *((double*) args->args[2]);
        }
	if (args->arg_type[3] == DECIMAL_RESULT) {
            string2double(args->args[3],lon2);
        }
        else {
	    lon2 = *((double*) args->args[3]);
        }

	return GeoCalc::EllipsoidDistance(lat1,lon1,lat2,lon2);
}


/*****************************
** ellipse_arc_length
******************************/

my_bool ellipse_arc_length_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 4)
	{
		strcpy(message, "ELLIPSE_ARC_LENGTH() requires four arguments");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
  else if ((args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT) ||
           (args->arg_type[1] != REAL_RESULT && args->arg_type[1] != DECIMAL_RESULT) ||
           (args->arg_type[2] != REAL_RESULT && args->arg_type[2] != DECIMAL_RESULT) ||
           (args->arg_type[3] != REAL_RESULT && args->arg_type[3] != DECIMAL_RESULT) )
	{
		strcpy(message, "ELLIPSE_ARC_LENGTH() requires four decimal arguments");
		return 1;
	}

  /* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void ellipse_arc_length_deinit(UDF_INIT *initid)
{
}

double ellipse_arc_length(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{

        double lat1;
        double lon1;
        double a;
        double f;

        // if one arg or more is null, then sends null
        *is_null = 0;
        if (!args->args[0] || !args->args[1] || !args->args[2] || !args->args[3]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],lat1);
        }
        else {
	    lat1 = *((double*) args->args[0]);
        }
	if (args->arg_type[1] == DECIMAL_RESULT) {
            string2double(args->args[1],lon1);
        }
        else {
	    lon1 = *((double*) args->args[1]);
        }
	if (args->arg_type[2] == DECIMAL_RESULT) {
            string2double(args->args[2],a);
        }
        else {
	    a = *((double*) args->args[2]);
        }
	if (args->arg_type[3] == DECIMAL_RESULT) {
            string2double(args->args[3],f);
        }
        else {
	    f = *((double*) args->args[3]);
        }

	return GeoCalc::EllipseArcLength(lat1,lon1,a,f);
}


/*****************************
** gc_distance
******************************/

my_bool gc_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 4)
	{
		strcpy(message, "GC_DISTANCE() requires four arguments");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
  else if ((args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT) ||
           (args->arg_type[1] != REAL_RESULT && args->arg_type[1] != DECIMAL_RESULT) ||
           (args->arg_type[2] != REAL_RESULT && args->arg_type[2] != DECIMAL_RESULT) ||
           (args->arg_type[3] != REAL_RESULT && args->arg_type[3] != DECIMAL_RESULT) )
	{
		strcpy(message, "GC_DISTANCE() requires four decimal arguments");
		return 1;
	}

	/* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void gc_distance_deinit(UDF_INIT *initid)
{
}

double gc_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{
        double lat1;
        double lon1;
        double lat2;
        double lon2;

        // if one arg or more is null, then sends null
        *is_null = 0;
        if (!args->args[0] || !args->args[1] || !args->args[2] || !args->args[3]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],lat1);
        }
        else {
	    lat1 = *((double*) args->args[0]);
        }
	if (args->arg_type[1] == DECIMAL_RESULT) {
            string2double(args->args[1],lon1);
        }
        else {
	    lon1 = *((double*) args->args[1]);
        }
	if (args->arg_type[2] == DECIMAL_RESULT) {
            string2double(args->args[2],lat2);
        }
        else {
	    lat2 = *((double*) args->args[2]);
        }
	if (args->arg_type[3] == DECIMAL_RESULT) {
            string2double(args->args[3],lon2);
        }
        else {
	    lon2 = *((double*) args->args[3]);
        }

	return GeoCalc::GCDistance(lat1,lon1,lat2,lon2);
}




/*****************************
** approx_distance
******************************/

my_bool approx_distance_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 4)
	{
		strcpy(message, "APPROX_DISTANCE() requires four arguments");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
  else if ((args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT) ||
           (args->arg_type[1] != REAL_RESULT && args->arg_type[1] != DECIMAL_RESULT) ||
           (args->arg_type[2] != REAL_RESULT && args->arg_type[2] != DECIMAL_RESULT) ||
           (args->arg_type[3] != REAL_RESULT && args->arg_type[3] != DECIMAL_RESULT) )
	{
		strcpy(message, "APPROX_DISTANCE() requires four decimal arguments");
		return 1;
	}

  /* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void approx_distance_deinit(UDF_INIT *initid)
{
}

double approx_distance(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{

	double lat1;
	double lon1;
	double lat2;
	double lon2;

        // if one arg or more is null, then sends null
        *is_null = 0;
        if (!args->args[0] || !args->args[1] || !args->args[2] || !args->args[3]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],lat1);
        }
        else {
	    lat1 = *((double*) args->args[0]);
        }
	if (args->arg_type[1] == DECIMAL_RESULT) {
            string2double(args->args[1],lon1);
        }
        else {
	    lon1 = *((double*) args->args[1]);
        }
	if (args->arg_type[2] == DECIMAL_RESULT) {
            string2double(args->args[2],lat2);
        }
        else {
	    lat2 = *((double*) args->args[2]);
        }
	if (args->arg_type[3] == DECIMAL_RESULT) {
            string2double(args->args[3],lon2);
        }
        else {
	    lon2 = *((double*) args->args[3]);
        }

	return GeoCalc::ApproxDistance(lat1,lon1,lat2,lon2);
}

/*****************************
** km_to_miles
******************************/

my_bool km_to_miles_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 1)
	{
		strcpy(message, "KM_TO_MILES() requires one argument");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
	else if (args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT)
	{
		strcpy(message, "KM_TO_MILES() requires one decimal argument");
		return 1;
	}

  /* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void km_to_miles_deinit(UDF_INIT *initid)
{
}

double km_to_miles(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{
	double km;

        // if arg is null, then sends null
        *is_null = 0;
        if (!args->args[0]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],km);
        }
        else {
	    km = *((double*) args->args[0]);
        }

	return km / 1.609344;
}

/*****************************
** miles_to_km
******************************/

my_bool miles_to_km_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
	/* make sure user has provided four arguments */
	if (args->arg_count != 1)
	{
		strcpy(message, "MILES_TO_KM() requires one argument");
		return 1;
	}
	/* make sure all arguments are double (REAL or DECIMAL) */
	else if (args->arg_type[0] != REAL_RESULT && args->arg_type[0] != DECIMAL_RESULT)
	{
		strcpy(message, "MILES_TO_KM() requires one decimal argument");
		return 1;
	}

  /* may return null if one argument is null */
	initid->maybe_null = 1;

	return 0;
}

void miles_to_km_deinit(UDF_INIT *initid)
{
}

double miles_to_km(UDF_INIT *initid, UDF_ARGS *args, char *is_null,
                     char *error)
{
	double miles;

        // if arg is null, then sends null
        *is_null = 0;
        if (!args->args[0]) {
          *is_null = 1;
          return 0.0;
        }

	if (args->arg_type[0] == DECIMAL_RESULT) {
            string2double(args->args[0],miles);
        }
        else {
	    miles = *((double*) args->args[0]);
        }

	return miles * 1.609344;
}

bool string2double(char* digit, double& result)
{
     result = (double)atof(digit);
     if(result == 0)
          return FALSE;
     return TRUE;
}
